data-projector
==============

To rebuild from coffeescript source:

    $ npm install
    $ node_modules/.bin/browserify -t coffeeify src/DataProjector.coffee > DataProjector.js